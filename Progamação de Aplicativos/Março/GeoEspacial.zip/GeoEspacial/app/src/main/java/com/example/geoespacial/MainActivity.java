package com.example.geoespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
   RadioButton rat,rab, rav, rn, rf, rv, rh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        rat = findViewById(R.id.At);
        rab = findViewById(R.id.ABat);
        rav = findViewById(R.id.ABv);
        rn = findViewById(R.id.Nl);
        rf = findViewById(R.id.Af);
        rv = findViewById(R.id.V);
        rh = findViewById(R.id.A);
    }
    public void prosseguir(View Avançou) {
        Intent i = new Intent(this, TelaConta.class);
        if (rat.isChecked()) {
            TelaConta.conta = 1;
            startActivity(i);
        }
        else if (rab.isChecked()) {//formula da area total
            TelaConta.conta = 2;
            startActivity(i);
        }
        else if (rav.isChecked()) {//formula da area da base pelo volume
            TelaConta.conta = 3;
            startActivity(i);
        }
        else if (rn.isChecked())  {//Formula do numero de faces
            TelaConta.conta = 4;
            startActivity(i);
        }
        else if (rf.isChecked())  {//formula da area da face
            TelaConta.conta = 5;
            startActivity(i);
        }
        else if (rv.isChecked())  {// formula do volume
            TelaConta.conta = 6;
            startActivity(i);
        }
        else if (rh.isChecked())  {// formula da altura
            TelaConta.conta = 7;
            startActivity(i);
        }
        else{
            Toast.makeText( this , "Voce precisa selecionar uma opção", Toast.LENGTH_SHORT).show();

        }
    }
}